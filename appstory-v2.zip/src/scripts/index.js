import { registerSW } from 'virtual:pwa-register';
registerSW({ immediate: true });


import L from 'leaflet';
import 'leaflet/dist/leaflet.css';


import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

L.Marker.prototype.options.icon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
});

// CSS imports
import '../styles/styles.css';

import App from './pages/app';
import PushNotificationManager from './utils/push-notification.js';

// Global push notification manager
window.pushManager = new PushNotificationManager();

document.addEventListener('DOMContentLoaded', async () => {
  // Register service worker
 

   // PWA Install Prompt
  let deferredPrompt;
  const installButton = document.createElement('button');
  installButton.textContent = 'Install App';
  installButton.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #007bff;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    display: none;
    z-index: 1000;
  `;
  document.body.appendChild(installButton);

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    installButton.style.display = 'block';
  });

  installButton.addEventListener('click', async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      console.log(`User response to install prompt: ${outcome}`);
      deferredPrompt = null;
      installButton.style.display = 'none';
    }
  });

  window.addEventListener('appinstalled', () => {
    console.log('App was installed');
    installButton.style.display = 'none';
  });

  const app = new App({
    content: document.querySelector('#main-content'),
    drawerButton: document.querySelector('#drawer-button'),
    navigationDrawer: document.querySelector('#navigation-drawer'),
  });

  // Initialize navigation visibility based on login status
  const user = JSON.parse(localStorage.getItem('user'));
  if (user) {
    document.body.classList.add('logged-in');
  } else {
    document.body.classList.add('logged-out');
  }

  await app.renderPage();

  window.addEventListener('hashchange', async () => {
    await app.renderPage();
  });
});
